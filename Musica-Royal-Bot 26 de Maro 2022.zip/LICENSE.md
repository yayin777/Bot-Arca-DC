<h1 align="center">License for Discord-MusicBot</h1>

- The credits should not be changed.
- You can make your bot public ![EpicYay](https://cdn.discordapp.com/emojis/825211636171800596.gif?v=1&size=16)
- Don't republish like uploading a YouTube ![YouTube](https://cdn.discordapp.com/emojis/749289646097432667.png?v=1&size=16) video like im doing...
- Don't create your own repo, If you wanted to add my codes then just fork
- (Optional) Make sure to [subscribe](https://youtube.com/CodingWithSudhan) ;)
